/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (C) 2018 MediaTek Inc.
 */

#ifndef __MEDIATEK_GPIO_H
#define __MEDIATEK_GPIO_H

#endif	/* __MEDIATEK_GPIO_H */
